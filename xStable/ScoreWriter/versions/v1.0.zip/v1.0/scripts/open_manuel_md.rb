#!/usr/bin/env ruby
# encoding: UTF-8
# frozen_string_value: true
=begin

Pour ouvrir la version Markdown du manuel

=end
require_relative 'constants'


src = File.join(MUSIC_SCORE_FOLDER,'Manuel','Manuel.md')

`open -a Typora "#{src}"`

puts "Manuel Markdown ouvert"
