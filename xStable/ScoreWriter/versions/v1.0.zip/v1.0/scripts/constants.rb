# encoding: UTF-8
# frozen_string_value: true


MUSIC_SCORE_FOLDER = "/Users/philippeperret/Programmes/Icare_editions/music-score"
