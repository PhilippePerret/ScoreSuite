# TODO list

* Reconstituer le code complet à partir des mesures-code
* Pouvoir donner un code (avec des '|' pour délimiter les mesures) et le transformer en "mesures-code".
* Pour aggrandir/rappetisser tous les champs ou le champs sélectionné
* Découpage en petit input.text couvrant une mesure 
  - possibilité de les agrandir/diminuer
  - possibilité d'avoir un champ normal
  - possibilité de donner un code et qu'il soit découper en mesure
* Possibilité de récupérer tout le code (CMD+E) (mettre dans le PP avec )
* Possibilité de définir les options (piano, tune, etc.)

* Explication du programme
